from pathlib import Path

# absolute vs relative path
trip = Path("files", "countries.txt")
print(trip)

home = Path.home()
current = Path.cwd()
print('Мы сейчас в', current)
print('Домашняя директория -', home)

# Что нужно исправить, чтобы путь стал верным?
trip_absolute = Path(home, "countries.txt")
print('Путь к файлу со странами', trip_absolute)









# Иначе можно написать так
trip_absolute = Path.cwd() / 'countries.txt'

# attributes
print(trip)
print(trip.name)
print(trip.suffix)
print(trip.parent)
# methods
print('Это путь к папке?', trip_absolute.is_dir())
print('Это путь к файлу?', trip_absolute.is_file())


# Почему не сработает?
for txt_path in Path("files").glob("*.txt"):
    print(txt_path)

# Как написать такую проверку для папки months и названий с буквой А?
